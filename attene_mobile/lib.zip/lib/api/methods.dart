const String postMethod = 'post';
const String getMethod = 'get';
const String putMethod = 'put';
const String deleteMethod = 'delete';
const String patchMethod = 'patch';