import 'package:cross_file/cross_file.dart';

Future<bool> xfileExists(XFile file) async {
  return true;
}

Future<void> xfileDelete(XFile file) async {
}