export 'xfile_fs_stub.dart'
    if (dart.library.io) 'xfile_fs_io.dart';