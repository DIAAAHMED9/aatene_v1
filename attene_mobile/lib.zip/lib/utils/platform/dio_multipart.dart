export 'dio_multipart_stub.dart'
    if (dart.library.io) 'dio_multipart_io.dart';