import 'package:dio/dio.dart';

Future<MultipartFile?> dioMultipartFromLocalPath(String path) async {
  return null;
}