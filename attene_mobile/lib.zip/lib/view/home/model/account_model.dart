class DrawerAccount {
  final String name;
  final String avatar;

  DrawerAccount({
    required this.name,
    required this.avatar,
  });
}
