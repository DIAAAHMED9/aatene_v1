class AdModel {
  final String image;

  AdModel({required this.image});
}