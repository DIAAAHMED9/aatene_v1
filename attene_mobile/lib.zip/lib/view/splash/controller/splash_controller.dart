class SplashController {
  static Future<void> initializeApp() async {
    await Future.delayed(const Duration(seconds: 2));
  }
}