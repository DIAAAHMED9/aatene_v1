import 'package:flutter/material.dart';

class StoryVendorTheme {
  static const Color blueBg = Color(0xFF3F5F7A);
  static const Color primaryBlue = Color(0xFF2F6FED);
  static const Radius sheetRadius = Radius.circular(26);
}