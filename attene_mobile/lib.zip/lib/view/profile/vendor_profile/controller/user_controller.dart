import 'package:attene_mobile/general_index.dart';
import 'package:attene_mobile/view/profile/common/profile_controller_base.dart';

class VendorProfileController extends BaseProfileController {
  Map<String, dynamic> profileData = {};
  final MyAppController myAppController = Get.find<MyAppController>();

}