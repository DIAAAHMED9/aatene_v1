// Backwards-compatible shim for older imports using spaces in folder names.
export 'package:attene_mobile/view/profile/user_profile/controller/user_controller.dart';
