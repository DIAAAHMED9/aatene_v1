
export 'register/index.dart';
export 'verfication/index.dart';
export 'set_new_password/index.dart';
export 'forget_password/index.dart';
export 'login/index.dart';
export 'screen/start_page.dart';