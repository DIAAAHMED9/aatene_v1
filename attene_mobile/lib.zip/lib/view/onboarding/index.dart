export 'model/onboading_model.dart';
export 'package:flutter_animate/flutter_animate.dart';
export 'widgets/onboarding_page.dart';
export 'widgets/onboarding_dots.dart';
export 'widgets/curved_background.dart';
export 'controller/controller.dart';
export 'package:shared_preferences/shared_preferences.dart';
