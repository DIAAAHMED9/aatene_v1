import '../../../../general_index.dart';
import '../index.dart';

class AddServiceStepperScreen extends StatelessWidget {
  const AddServiceStepperScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const ServiceStepperScreen(isEditMode: false);
  }
}