// Compatibility export:
// Product feature widgets historically imported `ResponsiveWidgets` from here.
// The canonical implementation lives in `utils/responsive/responsive_widgets.dart`.

export '../../../utils/responsive/responsive_widgets.dart';
