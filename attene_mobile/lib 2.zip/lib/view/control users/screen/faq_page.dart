// Backwards-compatible shim for older imports using spaces in folder names.
export 'package:attene_mobile/view/control_users/screen/faq_page.dart';
