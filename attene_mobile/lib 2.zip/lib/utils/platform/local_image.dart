export 'local_image_web.dart' if (dart.library.io) 'local_image_io.dart';
