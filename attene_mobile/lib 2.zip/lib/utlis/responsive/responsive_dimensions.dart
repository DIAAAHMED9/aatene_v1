// Backwards-compatible shim for older imports using `utlis/`.
export 'package:attene_mobile/utils/responsive/responsive_dimensions.dart';
