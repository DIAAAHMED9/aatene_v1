// Auto-generated barrel file. Do not export generated parts.

export 'aatene_custom_text.dart';
export 'text_with_star.dart';
